# This bot was created solely by aaronn#2491 so if you need assistance, DM me!
# Firstly, make sure Node.js is installed. You can install it here: https://nodejs.org/en/download/
# For this bot's config you will need a Plivo account and $10-20 just so your account is charged, calls usually cost like $0.01 and the numbers are about $1 a month.
# The next part, you'll need the Plivo auth ID & Token aswell as the bot's token, the bot's token goes into the app.js file and the Plivo ID & Token go in 'callHandler.js'
# DM me for the rest. These include channelID, categoryID, roleID etc